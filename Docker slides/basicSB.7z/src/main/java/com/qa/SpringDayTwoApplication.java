package com.qa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDayTwoApplication {
	
	

	public static void main(String[] args) {
		SpringApplication.run(SpringDayTwoApplication.class, args);
		
		
		
		
	}
}
